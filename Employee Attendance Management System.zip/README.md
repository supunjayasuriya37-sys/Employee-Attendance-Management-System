
  # Employee Attendance Management System

  This is a code bundle for Employee Attendance Management System. The original project is available at https://www.figma.com/design/MNUDZUkIzhPaweOqGprjvt/Employee-Attendance-Management-System.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  